package polymorphism2;

public interface Speaker {

	void volumeUp();

	void volumeDown();

}